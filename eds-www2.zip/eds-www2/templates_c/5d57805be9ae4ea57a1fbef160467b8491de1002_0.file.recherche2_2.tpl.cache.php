<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:51:36
  from 'C:\wamp64\www\templates\recherche2_2.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84e28ec8508_79808457',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5d57805be9ae4ea57a1fbef160467b8491de1002' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\recherche2_2.tpl',
      1 => 1572383874,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc84e28ec8508_79808457 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '15087647375dc84e28e8ceb2_35243494';
?>
<!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Description</td>
                <td>Type</td>
            </tr>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tabResult']->value, 'vn', false, 'kn');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['kn']->value => $_smarty_tpl->tpl_vars['vn']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['desc'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['type'];?>
</td>
                </tr> 
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
	</body>
</html>
<?php }
}
