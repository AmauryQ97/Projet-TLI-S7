<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:49:38
  from 'C:\wamp64\www\templates\recherche2_1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84db25a83a6_66821636',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5a4d7fd05573ebba43b94959941cc1bc02525620' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\recherche2_1.tpl',
      1 => 1572383016,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc84db25a83a6_66821636 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '3505593485dc84db257d7f9_27099121';
?>
<!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Description</td>
                <td>Meridien</td>
            </tr>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tabResult']->value, 'vn', false, 'kn');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['kn']->value => $_smarty_tpl->tpl_vars['vn']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['desc'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['nom'];?>
</td>
                </tr> 
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
	</body>
</html>
<?php }
}
