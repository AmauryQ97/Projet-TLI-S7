<?php
/* Smarty version 3.1.33, created on 2019-11-10 12:34:30
  from 'C:\wamp64\www\templates\pathologies.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc803d6246859_58347156',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fccddea1ec3551384d980462b2f0c4b015dcfdc4' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\pathologies.tpl',
      1 => 1572872182,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:menu.tpl' => 1,
  ),
),false)) {
function content_5dc803d6246859_58347156 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '9059822725dc803d62399e7_12258377';
?>
<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

 <head>
	<?php $_smarty_tpl->_subTemplateRender('file:menu.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?> 
    <meta charset="utf-8"/>
    <link rel="stylesheet" href='../CSS/design.css'>
	<?php echo '<script'; ?>
 type="text/javascript" src="../Scripts/script.js"><?php echo '</script'; ?>
>
    <title>Pathologies</title>
  </head>
  <body>
    <span>
      <p>Cette page vous permez d'obtenir des informations sur les principales pathologies en acupuncture</p>
    </span>
      <form action="../Controler/controler_pathologie.php" method="POST">
      <div>
        <h2>Moteur de recherche</h2>
            <div id="cas1">
              <label for="all_path">Afficher toutes les pathologies principales</label>
              <input type="checkbox" name="all_path" checked>
              <label for="pat1">Pathologies de méridien</label>
              <input type="checkbox" name="pat1" value="m">
              <label for="pat2">Pathologies d’organe/viscère (tsang/fu)</label>
              <input type="checkbox" name="pat2" value="l">
              <label for="pat3">Pathologies des tendino-musculaires (jing jin)</label>
              <input type="checkbox" name="pat3" value="j">
              <label for="pat4">Pathologie des branches (voies luo)</label>
              <input type="checkbox" name="pat4" value="tf">
              <label for="pat5">Pathologies des merveilleux vaisseaux</label>
              <input type="checkbox" name="pat5" value="me">
            </div> 
            <div>
              <button id="cas2_button">Afficher/Cacher la recherche par filtre</button>
              <div id="cas2">
                <label for="filtre">Filtre:</label>
                <select name="filtre" id="filtre">
                  <option value="df"></option>
                  <option value="me">Meridien</option>
                  <option value="tp">Type de pathologie</option>
                  <option value="ca">Caractéristique</option>
                </select>
                <div id=filtre_me>
                  <label for="filtre_value">Indiquez un nom de méridien :</label>
                  <input type="text" name="filtre_value">
                </div>
                <div id=filtre_tp>
                  <label for="filtre_value_tp">Indiquez une caractéristique de pathologie:</label>
                  <input type="text" name="filtre_value_tp">
                </div>
                <div id=filtre_ca>
                  <label for="filtre_value">Choisissez un type de pathologie:</label>
                  <select name="filtre_value">
                      <option value="df"></option>
                      <option value="i">Interne</option>
                      <option value="e">Externe</option>
                      <option value="p">Plein</option>
                      <option value="v">Vide</option>
                      <option value="c">Chaud</option>
                      <option value="f">Froid</option>
                    </select>
                </div>
              </div>
          </div>
          <button id="cas3_button">Afficher/Cacher la recherche par symptome</button>
          <div id="cas3">
            <div>
            <label for="symptome">Symptôme:</label>
            <input type="text" name="symptome">
            </div>
          </div>
          <div>
            <button type="reset">Annuler</button>
            <button type="submit" name="recherche">Rechercher</button>
          </div>
          </div>
        </form>
    </div>
  </body>

</html><?php }
}
