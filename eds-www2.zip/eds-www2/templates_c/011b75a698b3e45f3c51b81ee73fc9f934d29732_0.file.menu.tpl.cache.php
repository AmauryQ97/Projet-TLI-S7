<?php
/* Smarty version 3.1.33, created on 2019-11-10 12:34:30
  from 'C:\wamp64\www\templates\menu.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc803d625c6a7_53174564',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '011b75a698b3e45f3c51b81ee73fc9f934d29732' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\menu.tpl',
      1 => 1572871866,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc803d625c6a7_53174564 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '18784842365dc803d6254887_57580678';
?>
<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<link rel="stylesheet" href="../CSS/menu.css">
</head>

<body>

<header>
<?php if ($_smarty_tpl->tpl_vars['connect']->value == 'yes') {?>
	<div id="menu">
	<ul>
	  <li><a>Menu</a>
		<ul>
		  <li><a class = "cache" href="index.php?nom=index&id=1">Accueil</a></li>
		  <li><a class = "cache" href="index.php?nom=patho&id=1">Pathologies</a></li>
		  <li><a class = "cache" href="index.php?nom=info&id=1">Informations</a></li>
		</ul>
	  </li>
	  <li class ="test">
		<a href="index.php?action=deco&id=2">Deconnexion</a>
		
	  </li>
	</ul>

	</div>
	
<?php } else { ?>
	<div id="menu">
	<ul>
	  <li><a>Menu</a>
		<ul>
		  <li><a class = "cache" href="index.php?nom=index&id=1">Accueil</a></li>
		  <li><a class = "cache" href="index.php?nom=patho&id=1">Pathologies</a></li>
		  <li><a class = "cache" href="index.php?nom=info&id=1">Informations</a></li>
		</ul>
	  </li>
	  <li class ="test">
		<a href="index.php?nom=connexion&id=1">Connexion</a>
		
	  </li>
	  <li class ="test">
		<a href="index.php?nom=inscription&id=1">Inscription</a>
	  </li>
	</ul>

	</div>
	
<?php }?>
</header>
</body>
</html><?php }
}
