<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:44:07
  from 'C:\wamp64\www\templates\recherche3.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84c67102271_71685910',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e6ca990bd2a8db1c9bf973ee29f0b237fb860507' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\recherche3.tpl',
      1 => 1572382310,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc84c67102271_71685910 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '1119013925dc84c670d4944_07739492';
?>
<!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Nom</td>
                <td>Description</td>
            </tr>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tabResult']->value, 'vn', false, 'kn');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['kn']->value => $_smarty_tpl->tpl_vars['vn']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value[0];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value[1];?>
</td>
                </tr> 
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
	</body>
</html>
<?php }
}
