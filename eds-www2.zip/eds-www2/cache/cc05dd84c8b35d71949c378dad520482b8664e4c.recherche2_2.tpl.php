<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:51:36
  from 'C:\wamp64\www\templates\recherche2_2.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84e28eeeeb1_17720657',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5d57805be9ae4ea57a1fbef160467b8491de1002' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\recherche2_2.tpl',
      1 => 1572383874,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dc84e28eeeeb1_17720657 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Description</td>
                <td>Type</td>
            </tr>
                            <tr>
                    <td></td>
                    <td></td>
                </tr> 
                    </table>
	</body>
</html>
<?php }
}
