<?php
/* Smarty version 3.1.33, created on 2019-11-04 14:43:33
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates\recherche1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc02b05267d52_12071381',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '39cd32634a01a6ecef9e49b8cf82bb4d5ed4dd3d' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\recherche1.tpl',
      1 => 1572875012,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dc02b05267d52_12071381 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Nom</td>
                <td>Type</td>
                <td>Description</td>
            </tr>
                            <tr>
                    <td><br />
<b>Warning</b>:  Illegal string offset 'name' in <b>C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates_c\39cd32634a01a6ecef9e49b8cf82bb4d5ed4dd3d_0.file.recherche1.tpl.cache.php</b> on line <b>44</b><br />
A</td>
                    <td><br />
<b>Warning</b>:  Illegal string offset 'carac' in <b>C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates_c\39cd32634a01a6ecef9e49b8cf82bb4d5ed4dd3d_0.file.recherche1.tpl.cache.php</b> on line <b>46</b><br />
A</td>
                    <td>
                        <ul>
                                                            <li><br />
<b>Warning</b>:  Illegal string offset 'desc' in <b>C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates_c\39cd32634a01a6ecef9e49b8cf82bb4d5ed4dd3d_0.file.recherche1.tpl.cache.php</b> on line <b>55</b><br />
A</li> 
                                                    </ul>
                    </td>
                </tr> 
                    </table>
	</body>
</html>
<?php }
}
