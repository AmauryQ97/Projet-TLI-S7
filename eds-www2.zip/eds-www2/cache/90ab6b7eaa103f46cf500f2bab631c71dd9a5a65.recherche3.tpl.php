<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:51:10
  from 'C:\wamp64\www\templates\recherche3.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84e0e8c32a7_21882011',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e6ca990bd2a8db1c9bf973ee29f0b237fb860507' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\recherche3.tpl',
      1 => 1572382310,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dc84e0e8c32a7_21882011 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Nom</td>
                <td>Description</td>
            </tr>
                    </table>
	</body>
</html>
<?php }
}
