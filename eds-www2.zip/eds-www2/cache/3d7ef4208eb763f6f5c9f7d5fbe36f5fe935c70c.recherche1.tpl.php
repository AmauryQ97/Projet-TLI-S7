<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:54:02
  from 'C:\wamp64\www\templates\recherche1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84ebac6dd51_33736923',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1efb5e806716b7531a75b5a02f99abf509898b13' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\recherche1.tpl',
      1 => 1573388833,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dc84ebac6dd51_33736923 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	<body>
		<h1>Resultat recherche</h1>
		<table>
            <tr>
                <td>Nom</td>
                <td>Type</td>
                <td>Description</td>
            </tr>
                    </table>
	</body>
</html>
<?php }
}
