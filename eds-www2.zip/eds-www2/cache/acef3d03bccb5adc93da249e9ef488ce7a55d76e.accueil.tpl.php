<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:54:02
  from 'C:\wamp64\www\templates\accueil.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84ebaca3523_47929476',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '961cc9b401eb4c25bd7cb794116144d826e39ccf' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\accueil.tpl',
      1 => 1572871836,
      2 => 'file',
    ),
    '011b75a698b3e45f3c51b81ee73fc9f934d29732' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\menu.tpl',
      1 => 1572871866,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dc84ebaca3523_47929476 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<link rel="stylesheet" href="../CSS/menu.css">
</head>

<body>

<header>
	<div id="menu">
	<ul>
	  <li><a>Menu</a>
		<ul>
		  <li><a class = "cache" href="index.php?nom=index&id=1">Accueil</a></li>
		  <li><a class = "cache" href="index.php?nom=patho&id=1">Pathologies</a></li>
		  <li><a class = "cache" href="index.php?nom=info&id=1">Informations</a></li>
		</ul>
	  </li>
	  <li class ="test">
		<a href="index.php?action=deco&id=2">Deconnexion</a>
		
	  </li>
	</ul>

	</div>
	
</header>
</body>
</html><head>
<link rel="stylesheet" href="../CSS/index.css">
</head>
<div>

</div>
<div>
<title>Association des acupuncteurs soucieux</title>
<body>

<h1>Association des acupuncteurs soucieux</h1>

<p> un méridien en acupuncture est un chemin composé de différentes branches lié à un organe, à un viscère ou à un « merveilleux vaisseau ». Sa partie superficielle contient les fameux « points » d’acupuncture que les praticiens poncturent, chauffent ou massent. Les différentes branches des chemins n’empruntent pas forcément des trajets anatomiques ou physiologiques, ce qui est l’un des mystères que la médecine occidentale n’a pas encore pu expliquer scientifiquement </p>
</div>
</body>
</html>
<?php }
}
