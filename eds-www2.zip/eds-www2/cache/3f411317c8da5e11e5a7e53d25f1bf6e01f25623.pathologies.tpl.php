<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:52:45
  from 'C:\wamp64\www\templates\pathologies.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84e6d516287_78265168',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fccddea1ec3551384d980462b2f0c4b015dcfdc4' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\pathologies.tpl',
      1 => 1572872182,
      2 => 'file',
    ),
    '011b75a698b3e45f3c51b81ee73fc9f934d29732' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\menu.tpl',
      1 => 1572871866,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dc84e6d516287_78265168 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

 <head>
	<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<link rel="stylesheet" href="../CSS/menu.css">
</head>

<body>

<header>
	<div id="menu">
	<ul>
	  <li><a>Menu</a>
		<ul>
		  <li><a class = "cache" href="index.php?nom=index&id=1">Accueil</a></li>
		  <li><a class = "cache" href="index.php?nom=patho&id=1">Pathologies</a></li>
		  <li><a class = "cache" href="index.php?nom=info&id=1">Informations</a></li>
		</ul>
	  </li>
	  <li class ="test">
		<a href="index.php?action=deco&id=2">Deconnexion</a>
		
	  </li>
	</ul>

	</div>
	
</header>
</body>
</html> 
    <meta charset="utf-8"/>
    <link rel="stylesheet" href='../CSS/design.css'>
	<script type="text/javascript" src="../Scripts/script.js"></script>
    <title>Pathologies</title>
  </head>
  <body>
    <span>
      <p>Cette page vous permez d'obtenir des informations sur les principales pathologies en acupuncture</p>
    </span>
      <form action="../Controler/controler_pathologie.php" method="POST">
      <div>
        <h2>Moteur de recherche</h2>
            <div id="cas1">
              <label for="all_path">Afficher toutes les pathologies principales</label>
              <input type="checkbox" name="all_path" checked>
              <label for="pat1">Pathologies de méridien</label>
              <input type="checkbox" name="pat1" value="m">
              <label for="pat2">Pathologies d’organe/viscère (tsang/fu)</label>
              <input type="checkbox" name="pat2" value="l">
              <label for="pat3">Pathologies des tendino-musculaires (jing jin)</label>
              <input type="checkbox" name="pat3" value="j">
              <label for="pat4">Pathologie des branches (voies luo)</label>
              <input type="checkbox" name="pat4" value="tf">
              <label for="pat5">Pathologies des merveilleux vaisseaux</label>
              <input type="checkbox" name="pat5" value="me">
            </div> 
            <div>
              <button id="cas2_button">Afficher/Cacher la recherche par filtre</button>
              <div id="cas2">
                <label for="filtre">Filtre:</label>
                <select name="filtre" id="filtre">
                  <option value="df"></option>
                  <option value="me">Meridien</option>
                  <option value="tp">Type de pathologie</option>
                  <option value="ca">Caractéristique</option>
                </select>
                <div id=filtre_me>
                  <label for="filtre_value">Indiquez un nom de méridien :</label>
                  <input type="text" name="filtre_value">
                </div>
                <div id=filtre_tp>
                  <label for="filtre_value_tp">Indiquez une caractéristique de pathologie:</label>
                  <input type="text" name="filtre_value_tp">
                </div>
                <div id=filtre_ca>
                  <label for="filtre_value">Choisissez un type de pathologie:</label>
                  <select name="filtre_value">
                      <option value="df"></option>
                      <option value="i">Interne</option>
                      <option value="e">Externe</option>
                      <option value="p">Plein</option>
                      <option value="v">Vide</option>
                      <option value="c">Chaud</option>
                      <option value="f">Froid</option>
                    </select>
                </div>
              </div>
          </div>
          <button id="cas3_button">Afficher/Cacher la recherche par symptome</button>
          <div id="cas3">
            <div>
            <label for="symptome">Symptôme:</label>
            <input type="text" name="symptome">
            </div>
          </div>
          <div>
            <button type="reset">Annuler</button>
            <button type="submit" name="recherche">Rechercher</button>
          </div>
          </div>
        </form>
    </div>
  </body>

</html><?php }
}
