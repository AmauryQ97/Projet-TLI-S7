<?php
/* Smarty version 3.1.33, created on 2019-10-18 11:30:50
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates\patho.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5da9864a500054_24921232',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '98b0668785d12770af4bf3789a8799c17bc92195' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\patho.tpl',
      1 => 1570182157,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5da9864a500054_24921232 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="CSS/design.css">
    <script src="script.js"></script>
    <title>Pathologies</title>
  </head>

  <body>

<div>
    <span>
      <p>Cette page vous permez d'obtenir des informations sur les principales pathologies en acupuncture</p>
    </span>
      <div>
        <h2>Recherche</h2>
          <div>
            <div>
            <label for="nom">Nom:</label>
            <input type="text" name="nom">
            </div>
            <div>
              <label for="filtre">Filtre:</label>
              <select name="filtre">
                <option value="df"></option>
                <option value="me">Meridien</option>
                <option value="tp">Type de pathologie</option>
                <option value="ca">Caractéristique</option>
              </select>
          </div>
           <div>
            <label for="critere">Critère:</label>
            <input type="text" name="critere"></ins>
           </div>
          <div>
            <label for="recherche">Valider</label>
            <input type="button" value="recherche">
          </div>
      </div>
    </div>
</div>	
</body>
</html><?php }
}
