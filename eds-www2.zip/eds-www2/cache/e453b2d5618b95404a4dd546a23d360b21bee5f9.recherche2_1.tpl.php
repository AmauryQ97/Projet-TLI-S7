<?php
/* Smarty version 3.1.33, created on 2019-11-04 14:45:08
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates\recherche2_1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc02b649c2383_33712882',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ff63e1d853bd854c002cfbe93f21c3179d24b4d3' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\recherche2_1.tpl',
      1 => 1572383014,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dc02b649c2383_33712882 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Description</td>
                <td>Meridien</td>
            </tr>
                            <tr>
                    <td><br />
<b>Warning</b>:  Illegal string offset 'desc' in <b>C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates_c\ff63e1d853bd854c002cfbe93f21c3179d24b4d3_0.file.recherche2_1.tpl.cache.php</b> on line <b>41</b><br />
A</td>
                    <td><br />
<b>Warning</b>:  Illegal string offset 'nom' in <b>C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates_c\ff63e1d853bd854c002cfbe93f21c3179d24b4d3_0.file.recherche2_1.tpl.cache.php</b> on line <b>43</b><br />
A</td>
                </tr> 
                    </table>
	</body>
</html>
<?php }
}
