<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:52:47
  from 'C:\wamp64\www\templates\connexion.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84e6f2d0823_68515029',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6d34c10e4535bfafe34c5f09d76aa45be3c17fa3' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\connexion.tpl',
      1 => 1571382910,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dc84e6f2d0823_68515029 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	<head>
		<meta charset="UTF-8">
		<title>Inscription</title>
		<link rel="stylesheet" href="CSS/inscription.css">
	</head>
	<body>
		<div>
			<h1>Connexion :</h1>
			<form action ="index.php?action=connexion&id=2" method = "POST">
				<input type="text" name="login" placeholder="Username">
				<input type="password" name="password" id ="password" placeholder="Password">
				<input type="submit" value="Se connecter">
			</form>		  
			<a href="index.php?nom=inscription&id=1">Pas encore inscrit ?</a> - <a href="mdp_oublie.html">Mot de passe oublié ?</a>
		</div>
	</body> 
</html><?php }
}
