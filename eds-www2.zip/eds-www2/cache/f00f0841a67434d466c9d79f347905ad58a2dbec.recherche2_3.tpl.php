<?php
/* Smarty version 3.1.33, created on 2019-11-10 17:51:01
  from 'C:\wamp64\www\templates\recherche2_3.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc84e05ab8060_81907783',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '38ddeb200716271b9b4bab417240b785cd63e624' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\recherche2_3.tpl',
      1 => 1572385334,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dc84e05ab8060_81907783 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Description</td>
                <td>Type</td>
            </tr>
                            <tr>
                    <td>zang poumon chaud</td>
                    <td>tfc</td>
                </tr> 
                            <tr>
                    <td>fu gros intestin chaud</td>
                    <td>tfc</td>
                </tr> 
                            <tr>
                    <td>fu estomac plein et chaud</td>
                    <td>tfpc</td>
                </tr> 
                            <tr>
                    <td>zang rate plein et chaud</td>
                    <td>tfpc</td>
                </tr> 
                            <tr>
                    <td>fu intestin grêle plein et chaud</td>
                    <td>tfpc</td>
                </tr> 
                            <tr>
                    <td>fu vessie plein et chaud</td>
                    <td>tfpc</td>
                </tr> 
                            <tr>
                    <td>fu vésicule biliaire chaud</td>
                    <td>tfc</td>
                </tr> 
                            <tr>
                    <td>zang foie chaud</td>
                    <td>tfc</td>
                </tr> 
                    </table>
	</body>
</html>
<?php }
}
