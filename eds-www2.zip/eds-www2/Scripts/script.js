//document.getElementById('filtre_me').style.display = "none";
//document.getElementById('filtre_tp').style.display = "none";
//document.getElementById('filtre_ca').style.display = "none";


function Hide (addr) { 
    document.getElementById(addr).style.display = "none";
    document.getElementById(addr).style.visibility = "hidden";	
}
function Show (addr) { 
    document.getElementById(addr).style.display = "block";
    document.getElementById(addr).style.visibility = "visible";	
}

function toggle(anId)
{
	if (document.getElementById(anId).style.visibility == "hidden" || document.getElementById(anId).style.display == "none")	{
        Show(anId);	
        //alert("ca marche");
    }
	else {	
        Hide(anId);	
    }
}
var element = document.getElementById('filtre');
var cas2_button = document.getElementById('cas2_button');
var cas3_button = document.getElementById('cas3_button');

cas2_button.addEventListener('click', function() {
    toggle('cas2');
});

cas3_button.addEventListener('click', function() {
    toggle('cas3');
});

element.addEventListener('change', function(e) {
    if (element.value == 'me' ){
        //document.getElementById('filtre_me').style.display = "block";
        //document.getElementById('filtre_tp').style.visibility = "visible";
        toggle('filtre_me');
    }
    else if (element.value == 'tp') {
        //document.getElementById('filtre_tp').style.display = "block";
        //document.getElementById('filtre_tp').style.visibility = "visible";
        toggle('filtre_tp');
    }
    else if (element.value == 'ca') {
        //document.getElementById('filtre_ca').style.display = "block";
        //document.getElementById('filtre_tp').style.visibility = "visible";
        toggle('filtre_ca');
    }
});
