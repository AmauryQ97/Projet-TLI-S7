<?php
$mail = $_GET['email'];
print("<center>Bonjour $mail</center>"); 
?>