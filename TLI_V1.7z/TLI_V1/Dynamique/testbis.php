
<?php
/* Exécute une requête préparée en associant des variables PHP */

$pdo = new PDO('mysql:host=localhost;dbname=test', 'root', '');     
$calories = "m%";
$sth = $pdo->prepare("SELECT pa.type, sy.desc FROM patho as pa 
join symptPatho as syp on pa.idP=syp.idP
join symptome as sy on syp.idS=sy.idS
WHERE pa.type LIKE :typepatho
ORDER BY pa.type");
$sth->bindValue(':typepatho', $calories);
//var_dump($sth);
$sth->execute();
var_dump($sth->fetchAll());
?>
