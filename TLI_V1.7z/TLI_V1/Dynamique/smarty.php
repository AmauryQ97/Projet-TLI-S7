<?php
	require("../Template/libs/Smarty.class.php");
	$smarty = new Smarty();
?>
	