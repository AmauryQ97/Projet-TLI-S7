<?php  
include ("smarty.php");
    
$pdo = new PDO('mysql:host=localhost;dbname=test', 'root', '',array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));     

if (isset($_POST['recherche']))
{
    $pat1 = array("name" => "Pathologies de méridiens", "carac" => "interne/externe");
    $pat2 = array("name" => "Pathologie des branches (voies luo)", "carac" => "plein/vide");
    $pat3 = array("name" => "Pathologies des tendino-musculaires (jing jin)", "carac" => "");
    $pat4 = array("name" => "Pathologies d'organes/viscère", "carac" => "plein/vide/chaud/froid");
    $pat5 = array("name" => "Pathologies des merveilleux vaisseaux", "carac" => "");
    $name = array();
    //Test type de recherche
    if (empty($_POST['nom']) AND ($_POST['filtre'] == "df") AND empty($_POST['symptome']))
    {
        //Cas 1: affiche les symptomes des principales patho
        //$typepatho = array();
        $typepatho = "";
        if(!empty($_POST['all_path']))
        {
        //$typepatho = "'m%' OR 'l%' OR 'j%' OR 'tf%' OR 'me%'"; //fonctionne pas --> je trouve pas de solution (la requête fonctionne avec 
                                                                //un argument pas quand il y en a plusieurs avec les OR..)
        $typepatho = array("m%","l%","j%","tf%","me%");
        array_push($name, $pat1, $pat2, $pat3, $pat4, $pat5);
        }
        else if(empty($_POST['all_path']))
        {
            $compteur = 0;
            if (!empty($_POST['pat1'])) {
                $compteur ++;
                //array_push($typepatho, "m%");
                $typepatho = $typepatho."m%";
                //$typepatho = $typepatho.$_POST['pat1'].'%';
                array_push($name, $pat1);
            }
            if (!empty($_POST['pat2'])) {              
                if ($compteur != 0) {
                    //$typepatho = $typepatho.' OR ';
                }
                $compteur ++;
                array_push($typepatho, "l%");
                array_push($name, $pat2);
            }
            if (!empty($_POST['pat3'])) {
                if ($compteur != 0) {
                    //$typepatho = $typepatho.' OR ';
                }
                $compteur ++;
                array_push($typepatho, "j%");
                array_push($name, $pat3);
            }
            if (!empty($_POST['pat4'])) {
                if ($compteur != 0) {
                    //$typepatho = $typepatho.' OR ';
                }
                $compteur ++;
                array_push($typepatho, "tf%");
                array_push($name, $pat4);
            }
            if (!empty($_POST['pat5'])) {
                if ($compteur != 0) {
                    //$typepatho = $typepatho.' OR ';
                }
                $compteur ++;
                array_push($typepatho, "me%");
                array_push($name, $pat5);
            }
        }
        var_dump($typepatho);
        $sql = "SELECT sy.desc FROM patho as pa 
        join symptPatho as syp on pa.idP=syp.idP
        join symptome as sy on syp.idS=sy.idS
        WHERE pa.type LIKE :typepatho
        ORDER BY pa.type";
        $prepare = $pdo->prepare($sql);
        /*$place_holders = implode("','",$typepatho); 
        var_dump($place_holders);
        $prepare = $pdo->prepare("SELECT sy.desc FROM patho as pa 
        join symptPatho as syp on pa.idP=syp.idP
        join symptome as sy on syp.idS=sy.idS
        WHERE pa.type[0] IN ($place_holders)
        ORDER BY pa.type");*/
        $prepare->bindValue(':typepatho', $typepatho);
        
        $res = $prepare ->execute();
        $tabResult = $prepare->fetchAll();
        $smarty ->assign("name", $name);
        $smarty ->assign("tabResult", $tabResult);
        $smarty ->display("recherche1.tpl");

    }
    //Cas 2 : affiche les pathologies en fonction d'un critère
    else if(empty($_POST['nom']) AND ($_POST['filtre'] != "df") AND empty($_POST['symptome'])) {
        $filtre = "";
        if ($_POST['filtre'] == "me") {
            $filtre = "%".$_POST['filtre_value']."%";
            $sql = "SELECT pa.desc, me.nom FROM patho AS pa
            JOIN meridien AS me
            WHERE me.nom LIKE :filtre";
            $prepare = $pdo->prepare($sql);
            $prepare->bindValue(':filtre', $filtre);
            $prepare->execute();
            $tabResult = $prepare->fetchAll();
            $smarty ->assign("tabResult", $tabResult);
            $smarty ->display("recherche2_1.tpl");// A modifier avec un distinct de la description
        }
        if ($_POST['filtre'] == "tp") { //necessite une conversion du nom vers la valeurs type ex : meridien = m
            $filtre = "";
            //$filtre = $_POST['filtre_value'][0];
            var_dump($_POST['filtre_value_tp']);
            if ('meridien' == $_POST['filtre_value_tp']) {
                $filtre = "m%";
            }
            else if ("organe/viscère" == $_POST['filtre_value_tp']) {
                $filtre = "tf%";
            }
            else if ("luo" == $_POST['filtre_value_tp']) {
                $filtre = "l%";
            }
            else if ("merveilleux vaisseaux" == $_POST['filtre_value_tp']) {
                $filtre = "me%";
            }
            else if ("jing jin" == $_POST['filtre_value_tp']) {
                $filtre = "j%";
            }
            $sql = "SELECT pa.desc, pa.type FROM patho AS pa WHERE pa.type LIKE :filtre";
            var_dump($filtre);
            $prepare = $pdo->prepare($sql);
            $prepare->bindValue(':filtre', $filtre);
            $prepare->execute();
            $tabResult = $prepare->fetchAll();
            var_dump($tabResult);
            //$smarty ->assign("tabResult", $tabResult);
            //$smarty ->display("recherche2_2.tpl");
        }
        if ($_POST['filtre'] == "ca") {
            var_dump($_POST['filtre_value'][0]);
            $filtre = "%".$_POST['filtre_value'][0];
            $sql = "SELECT pa.desc, pa.type FROM patho AS pa
            WHERE pa.type LIKE :filtre";
            $prepare = $pdo->prepare($sql);
            $prepare->bindValue(':filtre', $filtre);
            $prepare->execute();
            $tabResult = $prepare->fetchAll();
            //var_dump($tabResult);
            $smarty ->assign("tabResult", $tabResult);
            $smarty ->display("recherche2_3.tpl");
        }
        //$prepare = $pdo->prepare($sql);
        //$prepare->bindValue(':filtre', $filtre);
        

    }
    // cas 3: Affiche les patho en fonction des symptomes
    else if (empty($_POST['nom']) AND ($_POST['filtre'] == "df") AND !empty($_POST['symptome'])) {
        $sympt = '%'.$_POST['symptome'].'%';
        $sql = "SELECT pa.desc, sy.desc FROM patho AS pa
            JOIN symptPatho as syp on pa.idP=syp.idP
            JOIN symptome as sy on syp.idS=sy.idS
            WHERE sy.desc LIKE :sympt";
        $prepare = $pdo->prepare($sql);
        $prepare->bindValue(':sympt', $sympt);
        $prepare->execute();
        $tabResult = $prepare->fetchAll();
        $smarty ->assign("tabResult", $tabResult);
        $smarty ->display("recherche3.tpl");
    }
    else
    {
        $erreur= "Pour afficher toutes les pathologies selectionner la case correspondante";
    }
    
    //$smarty ->assign("erreur", $erreur);
    //$smarty ->display("inscription_V2.html");
		
}
else {

}
?>