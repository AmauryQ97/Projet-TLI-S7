<?php
/* Smarty version 3.1.33, created on 2019-10-29 21:51:00
  from 'C:\wamp64\www\Dynamique\recherche2_3.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5db8b4441298d1_45417481',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9dd7c91d9f778f1e8af483beada7098540676b32' => 
    array (
      0 => 'C:\\wamp64\\www\\Dynamique\\recherche2_3.tpl',
      1 => 1572385333,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db8b4441298d1_45417481 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Description</td>
                <td>Type</td>
            </tr>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tabResult']->value, 'vn', false, 'kn');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['kn']->value => $_smarty_tpl->tpl_vars['vn']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['desc'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['type'];?>
</td>
                </tr> 
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
	</body>
</html>
<?php }
}
