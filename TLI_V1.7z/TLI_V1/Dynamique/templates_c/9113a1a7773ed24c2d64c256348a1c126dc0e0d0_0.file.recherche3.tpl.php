<?php
/* Smarty version 3.1.33, created on 2019-10-29 20:52:01
  from 'C:\wamp64\www\Dynamique\recherche3.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5db8a6714dd7f8_52819637',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9113a1a7773ed24c2d64c256348a1c126dc0e0d0' => 
    array (
      0 => 'C:\\wamp64\\www\\Dynamique\\recherche3.tpl',
      1 => 1572382308,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db8a6714dd7f8_52819637 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Nom</td>
                <td>Description</td>
            </tr>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tabResult']->value, 'vn', false, 'kn');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['kn']->value => $_smarty_tpl->tpl_vars['vn']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value[0];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value[1];?>
</td>
                </tr> 
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
	</body>
</html>
<?php }
}
