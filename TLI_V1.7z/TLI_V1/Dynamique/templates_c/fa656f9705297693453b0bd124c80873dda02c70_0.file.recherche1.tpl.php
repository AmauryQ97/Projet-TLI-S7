<?php
/* Smarty version 3.1.33, created on 2019-10-29 19:22:43
  from 'C:\wamp64\www\Dynamique\recherche1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5db89183af64e8_46742860',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fa656f9705297693453b0bd124c80873dda02c70' => 
    array (
      0 => 'C:\\wamp64\\www\\Dynamique\\recherche1.tpl',
      1 => 1572297105,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db89183af64e8_46742860 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Nom</td>
                <td>Type</td>
                <td>Description</td>
            </tr>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['name']->value, 'vn', false, 'kn');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['kn']->value => $_smarty_tpl->tpl_vars['vn']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['name'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['carac'];?>
</td>
                    <td>
                        <ul>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tabResult']->value, 'v', false, 'k');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value => $_smarty_tpl->tpl_vars['v']->value) {
?>
                                <li><?php echo $_smarty_tpl->tpl_vars['v']->value['desc'];?>
</li> 
                            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </ul>
                    </td>
                </tr> 
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
	</body>
</html>
<?php }
}
