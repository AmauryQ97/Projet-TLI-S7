<?php
/* Smarty version 3.1.33, created on 2019-10-29 21:04:02
  from 'C:\wamp64\www\Dynamique\recherche2_1.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5db8a942ce7e26_70561256',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bde9984edd18ce47714abc98958f2f93ccc46f9e' => 
    array (
      0 => 'C:\\wamp64\\www\\Dynamique\\recherche2_1.tpl',
      1 => 1572383014,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db8a942ce7e26_70561256 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE>
 <html>
	<body>
		<h1>Test smarty</h1>
		<table>
            <tr>
                <td>Description</td>
                <td>Meridien</td>
            </tr>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tabResult']->value, 'vn', false, 'kn');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['kn']->value => $_smarty_tpl->tpl_vars['vn']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['desc'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['vn']->value['nom'];?>
</td>
                </tr> 
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </table>
	</body>
</html>
<?php }
}
