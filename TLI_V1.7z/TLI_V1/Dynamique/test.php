<?php
require("libs/smarty.class.php");
$smarty = new Smarty();
$smarty->assign("DATA","Hello");
$smarty->display("newSmartyTemplate.tpl")
?>