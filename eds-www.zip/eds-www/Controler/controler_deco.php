<?php

include ("../traitements/connect.php");

// initialisation des variables pour les différents traitements

	session_start();
	session_unset();
	session_destroy();
	header("Location: ../index.php?page=index&id=-1");

?>