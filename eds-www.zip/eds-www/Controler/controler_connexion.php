<?php

include ("../traitements/connect.php");

// initialisation des variables pour les différents traitements


$erreur ="";
$action = $_GET['action'];
	$user = $_GET['user'];
	$mdp = $_GET['mdp'];
	
	$insertuser = $bdd -> prepare("SELECT * FROM session WHERE identifiant= ? ");
	$insertuser -> execute(array($user));
	$trouve=0;

	while($donnees = $insertuser->fetch())
	{
		$mdp = sha1($mdp);

		if (($donnees['identifiant']==$user) AND ($donnees['mdp']==$mdp))
		{
			$trouve=1;
			$id=$donnees['id_session'];
		}
	}
	if ($trouve==1)
	{
		session_start();
		$_SESSION['name']=$user;
		$_SESSION['password']=$mdp;
		$_SESSION['id_session']=$id;
			
		header("Location: ../index.php?nom=connexion_valide&id=1");
	}
	else
		header("Location: ../index.php?action=erreur_3&id=3");
	
?>