<?php

include ("traitements/connect.php");

// initialisation des variables pour les différents traitements

$erreur ="";
$action = $_GET['action'];

	$user = $_GET['user'];
	$mdp = $_GET['mdp'];
	$nom = $_GET['nom'];
	$prenom = $_GET['prenom'];
	$mail = $_GET['mail'];
	$prof = $_GET['prof'];
	
	if(!empty($nom) AND !empty($prenom) AND !empty($mail)AND !empty($prof)AND !empty($user)AND !empty($mdp))
		{
			
			
			//echo "Tous les champs sont remplies";
			$fname = htmlspecialchars($nom); //htmlspecialchars => permet d'éviter les injections de code HTML
			$name = htmlspecialchars($prenom);
			$mail = htmlspecialchars($mail);
			$fonction = htmlspecialchars($prof);
			$user = htmlspecialchars($user);
			$passwd = sha1($mdp);
			
			
			
			
			//var_dump($insertuser->errorInfo());
			
			$requser = $bdd->prepare("SELECT identifiant FROM session WHERE identifiant=? ");
			$requser ->execute(array($user));
			$userexist = $requser->rowCount();
			
			$reqmail = $bdd->prepare("SELECT Mail FROM membres WHERE Mail=? ");
			$reqmail ->execute(array($mail));
			$mailexist = $reqmail->rowCount();
			
			
			echo $userexist, $mailexist;
			
			if(($userexist == 0 && $mailexist == 0))
			{
				
				$insertmbr = $bdd -> prepare ("INSERT INTO membres (Nom, Prenom, Mail, Profession) VALUES (?,?,?,?)");
				$insertmbr -> execute(array($fname, $name, $mail, $fonction));
				$insertuser = $bdd->prepare("INSERT INTO session (identifiant, mdp) VALUES(?,?)");
				$insertuser -> execute(array($user,$passwd));
				header("Location: ../index.php?nom=inscription_valide&id=1");
			}
			else
			{
				header("Location: ../index.php?action=eurreur_1&id=3");
				$erreur = "Utilisateur existant";
			}
			
			
		}
		else
		{
			//header("Location: ../index.php?action=eurreur_2&id=3");
			echo "Tous les champs doivent être remplis !";
		}
					
?>

