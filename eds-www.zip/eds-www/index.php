<?php

/**
 * Example Application
 *
 * @package Example-application
 */
require 'smarty-3.1.33/libs/Smarty.class.php';
$smarty = new Smarty;

echo '<pre>';
var_dump($_SERVER);

//$smarty->debugging = true;
$smarty->caching = true;
$smarty->cache_lifetime = 120;

session_start();
if (isset($_SESSION['name']))
{
	$smarty->assign('connect', 'yes');
	echo "je préfère";
}
else
{
	$smarty->assign('connect', 'no');
	echo "nani";
}
//include ("traitements/connect.php");

// récupération de la variable pour la template à afficher
if(!isset($_GET['nom']))
	$page = "index";
else
	$page = $_GET['nom'];

if (!isset($_GET['id']))
	$id = -1;
else
	$id = $_GET['id'];

if (!isset($_GET['action']))
	$action = "test";
else
	$action = $_GET['action'];



//gestion des actions sur les pages Connexion/Inscription
if ( $id == 2) // pour l'inscription et la connexion
{
	if ($action == "inscription")
	{
		$user = $_POST['utilisateur'];
		$mdp = $_POST['mdp'];
		$nom = $_POST['nom'];
		$prenom = $_POST['prenom'];
		$mail = $_POST['mail'];
		$prof = $_POST['profession'];
		
		header("Location: Controler/controler_inscription.php?&user=".$user."&mdp=".$mdp."&nom=".$nom."&prenom=".$prenom."&mail=".$mail."&prof=".$prof);
	}
	if ($action == "connexion")
	{
		$recup_user=$_POST['login'];
		$recup_Mdp=$_POST['password'];
		
		header("Location: Controler/controler_connexion.php?&user=".$recup_user."&mdp=".$recup_Mdp);
	}
	if ($action == "deco")
	{
		header("Location: Controler/controler_deco.php");
	}
}

if ( $id == 3)
{
	
}	
if ( $id == 1) //tous les affichages de templates 
{
	if ($page == "patho") 
	{
		$smarty->display('templates/pathologies.tpl');
	}
	if ($page == "info") 
	{
		$smarty->display('templates/info.tpl');
	}
	if ($page == "inscription") 
	{ 
		$smarty->display('templates/inscription.tpl');
	}
	if ($page == "connexion" || $page == "inscription_valide") 
	{
		$smarty->display('templates/connexion.tpl');
	}
	if ($page == "connexion_valide")
	{
		if (isset($_SESSION['name']) && isset($_SESSION['id_session']))
		{
			//$smarty->assign('connect', 'yes');
			$smarty->display('templates/accueil.tpl');
		}
		else
			echo "vous n'êtes pas connecté";
	}
}
if($page == "index")
	$smarty->display('templates/accueil.tpl');

?>