<?php
/* Smarty version 3.1.33, created on 2019-09-09 16:31:50
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\inscription.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d76625634ac44_84690935',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0db908ba32bdf6a310ea83e735b19be6e33974fd' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\inscription.html',
      1 => 1568038243,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d76625634ac44_84690935 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="UTF-8">
		<title>Inscription</title>
		<link rel="stylesheet" href="inscription_V2.css">
	</head>
	
	<body>
	<h1 id ="no_titre">Inscription</h1>
	
	<!--Formulaire d'inscription-->
	<form id="inscription" action="inscription.php" method="POST">	<!-- Method POST pour envoie du formulaire au serveur-->
	  <label>Nom :
	  <input type="text" name="nom" required></label> <br/>
	  <label>Prénom :</label> 
	  <input type="text" name="prenom" required><br/>
	  <label>Adresse mail :</label> 
	  <input type="email" name="mail" pattern="+@+" required><br/>
	  <label>Profession :</label>
	  <input type="text" name="profession" required> <br/>
	  <label>Nom utilisateur :</label>
	  <input type="text" name="utilisateur" required><br/>
	  <label>Mot de passe :</label>
	  <input type="password" name="mdp" required><br/>
	 <!--Attribut required pour que l'utilisateur a bien saisie toutes les données avant d'échanger avec le serveur-->
	 
	  <button type="reset">Annuler</button>
	  <button type="submit" name="form_inscription">Inscription</button>
	  </form>
	
	<?php echo $_smarty_tpl->tpl_vars['erreur']->value;?>

	
	
		
	  </body>
	  
</html><?php }
}
