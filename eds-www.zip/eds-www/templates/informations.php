<?php
include("menu.php");
?>
<html lang="fr">
	<head>
		<meta charset="UTF-8">
		<title>Inscription</title>
		<link rel="stylesheet" href="CSS/informations.css">
	</head>
	
	<body>
	<h1 id ="no_titre">Informations</h1>
	
	
	  </body>
	  
</html>