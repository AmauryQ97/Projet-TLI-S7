<?php
/* Smarty version 3.1.33, created on 2019-10-04 11:50:49
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates\accueil_co.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d9715f96393b6_59376380',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '99673b81ae763b0c4c697803a320dae84a31580c' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\accueil_co.tpl',
      1 => 1570182112,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:templates/menu_co.tpl' => 1,
  ),
),false)) {
function content_5d9715f96393b6_59376380 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '11218092365d9715f95ffe26_87535189';
?>
<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<link rel="stylesheet" href="CSS/index.css">
</head>
<div>
<?php $_smarty_tpl->_subTemplateRender('file:templates/menu_co.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</div>
<div>
<title>Association des acupuncteurs soucieux</title>
<body>

<h1>Association des acupuncteurs soucieux</h1>

<p> un méridien en acupuncture est un chemin composé de différentes branches lié à un organe, à un viscère ou à un « merveilleux vaisseau ». Sa partie superficielle contient les fameux « points » d’acupuncture que les praticiens poncturent, chauffent ou massent. Les différentes branches des chemins n’empruntent pas forcément des trajets anatomiques ou physiologiques, ce qui est l’un des mystères que la médecine occidentale n’a pas encore pu expliquer scientifiquement </p>
</div>
</body>
</html>
<?php }
}
