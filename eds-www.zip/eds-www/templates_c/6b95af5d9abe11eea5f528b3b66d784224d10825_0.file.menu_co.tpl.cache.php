<?php
/* Smarty version 3.1.33, created on 2019-10-04 11:41:42
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates\menu_co.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d9713d6893028_66728196',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6b95af5d9abe11eea5f528b3b66d784224d10825' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\menu_co.tpl',
      1 => 1570182095,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d9713d6893028_66728196 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '20015696735d9713d68665f5_79426337';
?>
<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<link rel="stylesheet" href="CSS/menu_co.css">
</head>

<body>

<div id="menu">
<ul>
  <li><a>Menu</a>
    <ul>
      <li><a class = "cache" href="index.php?nom=index&id=1">Accueil</a></li>
      <li><a class = "cache" href="index.php?nom=patho&id=1">Pathologies</a></li>
      <li><a class = "cache" href="index.php?nom=info&id=1">Informations</a></li>
    </ul>
  </li>
  <li class ="test">
	<a href="Traitements/traitement.php?action=deco">Deconnexion</a>
	
  </li>
</ul>

</div>

</body>
</html><?php }
}
