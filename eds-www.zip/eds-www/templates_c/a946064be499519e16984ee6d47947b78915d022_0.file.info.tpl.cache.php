<?php
/* Smarty version 3.1.33, created on 2019-11-04 14:12:02
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates\info.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc023a2e0aac1_83237979',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a946064be499519e16984ee6d47947b78915d022' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\info.tpl',
      1 => 1572873116,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:menu.tpl' => 1,
  ),
),false)) {
function content_5dc023a2e0aac1_83237979 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '3721238515dc023a2dda0a7_92371267';
?>
<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php $_smarty_tpl->_subTemplateRender('file:menu.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, $_smarty_tpl->cache_lifetime, array(), 0, false);
?> 
	<head>
		<meta charset="UTF-8">
		<title>Inscription</title>
		<link rel="stylesheet" href="CSS/informations.css">
	</head>
	
	<body>
	<h1 id ="no_titre">Informations</h1>
	
	
	  </body>
	  
</html><?php }
}
