<?php
/* Smarty version 3.1.33, created on 2019-11-04 13:51:56
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates\menu.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc01eec585318_79392954',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a83a7d2c0a81f72b608d1474f22b5c611077cddb' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\menu.tpl',
      1 => 1572871865,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc01eec585318_79392954 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '9031702625dc01eec538c63_10205739';
?>
<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<link rel="stylesheet" href="../CSS/menu.css">
</head>

<body>

<header>
<?php if ($_smarty_tpl->tpl_vars['connect']->value == 'yes') {?>
	<div id="menu">
	<ul>
	  <li><a>Menu</a>
		<ul>
		  <li><a class = "cache" href="index.php?nom=index&id=1">Accueil</a></li>
		  <li><a class = "cache" href="index.php?nom=patho&id=1">Pathologies</a></li>
		  <li><a class = "cache" href="index.php?nom=info&id=1">Informations</a></li>
		</ul>
	  </li>
	  <li class ="test">
		<a href="index.php?action=deco&id=2">Deconnexion</a>
		
	  </li>
	</ul>

	</div>
	
<?php } else { ?>
	<div id="menu">
	<ul>
	  <li><a>Menu</a>
		<ul>
		  <li><a class = "cache" href="index.php?nom=index&id=1">Accueil</a></li>
		  <li><a class = "cache" href="index.php?nom=patho&id=1">Pathologies</a></li>
		  <li><a class = "cache" href="index.php?nom=info&id=1">Informations</a></li>
		</ul>
	  </li>
	  <li class ="test">
		<a href="index.php?nom=connexion&id=1">Connexion</a>
		
	  </li>
	  <li class ="test">
		<a href="index.php?nom=inscription&id=1">Inscription</a>
	  </li>
	</ul>

	</div>
	
<?php }?>
</header>
</body>
</html><?php }
}
