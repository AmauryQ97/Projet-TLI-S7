<?php
/* Smarty version 3.1.33, created on 2019-11-04 13:57:52
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates\inscription.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dc02050a7fa86_48359538',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9be23c8e10d31688deab71776ea9cb53546efcbb' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\inscription.tpl',
      1 => 1572871895,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5dc02050a7fa86_48359538 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '7503957905dc02050a3c828_81970302';
?>
<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	<head>
		<meta charset="UTF-8">
		<title>Inscription</title>
		<link rel="stylesheet" href="inscription.css">
	</head>
	
	<body>
	<header>
			</header>
	<h1 id ="no_titre">Inscription</h1>
	
	<!--Formulaire d'inscription-->
	<form id="inscription" action="../index.php?action=inscription&id=2" method="POST">	<!-- Method POST pour envoie du formulaire au serveur-->
	  <label>Nom :
	  <input type="text" name="nom" required></label> <br/>
	  <label>Prénom :</label> 
	  <input type="text" name="prenom" required><br/>
	  <label>Adresse mail :</label> 
	  <input type="email" name="mail" pattern="+@+" required><br/>
	  <label>Profession :</label>
	  <input type="text" name="profession" required> <br/>
	  <label>Nom utilisateur :</label>
	  <input type="text" name="utilisateur" required><br/>
	  <label>Mot de passe :</label>
	  <input type="password" name="mdp" required><br/>
	 <!--Attribut required pour que l'utilisateur a bien saisie toutes les données avant d'échanger avec le serveur-->
	 
	  <button type="reset">Annuler</button>
	  <button type="submit" name="form_inscription">Inscription</button>
	  </form>
	
			
	  </body>
	  
</html><?php }
}
