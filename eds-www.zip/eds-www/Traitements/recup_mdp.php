<?php

    include('connect.php');

	$mail = $_POST["mail"];
            
			$sql="SELECT * FROM membres WHERE mail = '$mail'";
			$mail2=$bdd->query($sql);
                if(isset($mail2)){
                        // On génère un mot de passe à l'aide de la fonction RAND de PHP
                        $new_pass = rand();

                        $objet = 'Nouveau mot de passe';
                        $to = $mail;
						
						echo $new_pass;

                        //===== Création du header du mail.
                        $header = "From: NOM_DE_LA_PERSONNE <no-reply@test.com> \n";
                        $header .= "Reply-To: ".$to."\n";
                        $header .= "MIME-version: 1.0\n";
                        $header .= "Content-type: text/html; charset=utf-8\n";
                        $header .= "Content-Transfer-Encoding: 8bit";

                        //===== Contenu de votre message
                        $contenu =  "<html>".
                            "<body>".
                            "<p style='text-align: center; font-size: 18px'><b>Bonjour</b>,</p><br/>".
                            "<p style='text-align: justify'><i><b>Nouveau mot de passe : </b></i>".$new_pass."</p><br/>".
                            "</body>".
                            "</html>";
                        //===== Envoi du mail
                        mail($to, $objet, $contenu, $header);
						$bdd->exec=("UPDATE session SET mdp = '$new_pass',  WHERE mail = '$mail'");
                }       
               // header('Location: connexion.php');
                exit;
            
        
    
?>