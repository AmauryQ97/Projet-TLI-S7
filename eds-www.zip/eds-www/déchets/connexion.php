<html>

<head>

<link rel="stylesheet" href="CSS/menu.css">

</head>

				<div>
					<h1>Connexion :</h1><br>
				  <form action ="T_connexion.php" method = "POST">
					<input type="text" name="login" placeholder="Username">
					<input type="password" name="password" id ="password" placeholder="Password">
					<input type="submit" value="Se connecter">
				  </form>
				  <div>
					<a href="inscription_V2.html">Pas encore inscrit ?</a> - <a href="mdp_oublie.html">Mot de passe oublié ?</a>
				  </div>
	
</html>