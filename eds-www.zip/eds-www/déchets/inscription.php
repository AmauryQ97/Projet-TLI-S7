<?php

include ("smarty.php");
include ("connect.php");


$erreur ="";


if ($param ="inscription")
{
	if(!empty($_POST['nom']) AND !empty($_POST['prenom']) AND !empty($_POST['mail'])AND !empty($_POST['profession'])AND !empty($_POST['utilisateur'])AND !empty($_POST['mdp']))
		{
			
			
			//echo "Tous les champs sont remplies";
			$fname = htmlspecialchars($_POST['nom']); //htmlspecialchars => permet d'éviter les injections de code HTML
			$name = htmlspecialchars($_POST['prenom']);
			$mail = htmlspecialchars($_POST['mail']);
			$fonction = htmlspecialchars($_POST['profession']);
			$user = htmlspecialchars($_POST['utilisateur']);
			$passwd = sha1($_POST['mdp']);
			
			
			
			
			//var_dump($insertuser->errorInfo());
			
			$requser = $bdd->prepare("SELECT Nom FROM membres WHERE identifiant=? ");
			$requser ->execute(array($user));
			$userexist = $requser->rowCount();
			
			$reqmail = $bdd->prepare("SELECT Nom FROM membres WHERE mail=? ");
			$reqmail ->execute(array($mail));
			$mailexist = $reqmail->rowCount();
			
			
			
			if(($userexist == 0 && $mailexist == 0))
			{
				
				$insertmbr = $bdd -> prepare ("INSERT INTO membres (nom, prenom, mail, profession) VALUES (?,?,?,?)");
				$insertmbr -> execute(array($fname, $name, $mail, $fonction));
				$insertuser = $bdd->prepare("INSERT INTO membres (utilisateur, mdp) VALUES(?,?)");
				$insertuser -> execute(array($user,$passwd));
				//header('Location: connexion.php'); // redirige l'utilisateur sur la page connexion.html après création de son compte
			}
			else
			{
				$erreur = "Utilisateur existant";
			}
			
			
		}
		else
		{
			$erreur= "Tous les champs doivent être remplies !";
		}
		
		
		
	}
	
?>

