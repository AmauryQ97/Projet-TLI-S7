<?php
include("menu.php");
include("connect.php");
?>
<html lang="fr">
  <head>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="CSS/design.css">
    <script src="script.js"></script>
    <title>Pathologies</title>
  </head>
  <body>
    <span>
      <p>Cette page vous permez d'obtenir des informations sur les principales pathologies en acupuncture</p>
    </span>
      <div>
        <h2>Recherche</h2>
          <div>
            <div>
            <label for="nom">Nom:</label>
            <input type="text" name="nom">
            </div>
            <div>
              <label for="filtre">Filtre:</label>
              <select name="filtre">
                <option value="df"></option>
                <option value="me">Meridien</option>
                <option value="tp">Type de pathologie</option>
                <option value="ca">Caractéristique</option>
              </select>
          </div>
           <div>
            <label for="critere">Critère:</label>
            <input type="text" name="critere"></ins>
           </div>
          <div>
            <label for="recherche">Valider</label>
            <input type="button" value="recherche">
          </div>
      </div>
    </div>
<?php

$sql1 = "select * FROM patho"; 
$test1=$bdd->query($sql1);

while($donnees= $test1->fetch())     
 {
?>
<div>
<table>
	<tr>
		<td><?php echo $donnees['idP'];?></td>
		<td><?php echo $donnees['mer'];?></td>
		<td><?php echo $donnees['type'];?></td>
		<td><?php echo $donnees['desc'];?></td>

	</tr>
</table>
</div>
<?php
 }
?>	
  </body>
</html>