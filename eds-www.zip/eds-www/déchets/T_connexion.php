<?php
//ceci est la page envoi 
// Partie 1 : Récupération des données
// Partie 2 : Connexion à la BD en PDO
// Partie 3 : Insertion des données

//Partie 1 *************************************************

$recup_nom=$_POST['login'];
$recup_Mdp=$_POST['password'];

//Partie 2 **************************************************
include('connect.php');

//Partie 3 ************************************************
$insertuser = $bdd -> prepare("SELECT * FROM session WHERE identifiant= ? ");
$insertuser -> execute(array($recup_nom));
$trouve=0;

while($donnees = $insertuser->fetch()){
if (($donnees['identifiant']==$recup_nom) AND ($donnees['mdp']==$recup_Mdp)){
	$trouve=1;
	$id=$donnees['id_session'];
}
}
if ($trouve==1)
{
   		 
		 session_start();
		 $_SESSION['name']=$recup_nom;
		 $_SESSION['password']=$recup_Mdp;
		 $_SESSION['id']=$id;
		 header('Location:index.php');	 
		
}
else
	header('Location:fail.php');
$bdd=NULL;
$insertuser->closeCursor();
?>
