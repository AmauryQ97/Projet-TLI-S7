<?php
/* Smarty version 3.1.33, created on 2019-11-03 22:18:31
  from 'C:\Program Files (x86)\EasyPHP-Devserver-17\eds-www\templates\accueil.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5dbf4427657f34_35954174',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'db52cfb0ed208b432573e1a8f09ab7a3467c744b' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\accueil.tpl',
      1 => 1571381336,
      2 => 'file',
    ),
    'a83a7d2c0a81f72b608d1474f22b5c611077cddb' => 
    array (
      0 => 'C:\\Program Files (x86)\\EasyPHP-Devserver-17\\eds-www\\templates\\menu.tpl',
      1 => 1571390708,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5dbf4427657f34_35954174 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<link rel="stylesheet" href="CSS/index.css">
</head>
<div>
<!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<link rel="stylesheet" href="CSS/menu.css">
</head>

<body>

<header>
	<div id="menu">
	<ul>
	  <li><a>Menu</a>
		<ul>
		  <li><a class = "cache" href="index.php?nom=index&id=1">Accueil</a></li>
		  <li><a class = "cache" href="index.php?nom=patho&id=1">Pathologies</a></li>
		  <li><a class = "cache" href="index.php?nom=info&id=1">Informations</a></li>
		</ul>
	  </li>
	  <li class ="test">
		<a href="index.php?nom=connexion&id=1">Connexion</a>
		
	  </li>
	  <li class ="test">
		<a href="index.php?nom=inscription&id=1">Inscription</a>
	  </li>
	</ul>

	</div>
	
</header>
</body>
</html></div>
<div>
<title>Association des acupuncteurs soucieux</title>
<body>

<h1>Association des acupuncteurs soucieux</h1>

<p> un méridien en acupuncture est un chemin composé de différentes branches lié à un organe, à un viscère ou à un « merveilleux vaisseau ». Sa partie superficielle contient les fameux « points » d’acupuncture que les praticiens poncturent, chauffent ou massent. Les différentes branches des chemins n’empruntent pas forcément des trajets anatomiques ou physiologiques, ce qui est l’un des mystères que la médecine occidentale n’a pas encore pu expliquer scientifiquement </p>
</div>
</body>
</html>
<?php }
}
