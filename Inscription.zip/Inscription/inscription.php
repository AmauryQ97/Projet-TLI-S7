<?php

include ("smarty.php");

$bdd = new PDO('mysql:host=127.0.0.1;dbname=projet_tli','root','');
$erreur ="";


if (isset($_POST['form_inscription']))
	
	{
		if(!empty($_POST['nom']) AND !empty($_POST['prenom']) AND !empty($_POST['mail'])AND !empty($_POST['profession'])AND !empty($_POST['utilisateur'])AND !empty($_POST['mdp']))
		{
			
			
			//echo "Tous les champs sont remplies";
			$fname = htmlspecialchars($_POST['nom']); //htmlspecialchars => permet d'éviter les injections de code
			$name = htmlspecialchars($_POST['prenom']);
			$mail = htmlspecialchars($_POST['mail']);
			$fonction = htmlspecialchars($_POST['profession']);
			$user = htmlspecialchars($_POST['utilisateur']);
			$passwd = sha1($_POST['mdp']);
			
			$insertuser = $bdd -> prepare ("INSERT INTO membres (nom, prenom, mail, profession) VALUES (?,?,?,?)");
			$insertuser -> execute(array($fname, $name, $mail, $fonction));
			
			/*echo '<pre>';
			var_dump($insertuser->errorInfo());*/
			
			//$userlength = strlen($user); // nbre de caractères saisie pour l'utilisateur
				$insertmbr = $bdd->prepare("INSERT INTO sessions (utilisateur, mdp) VALUES(?,?)");
				$insertmbr -> execute(array($user,$passwd));
				header('Location: connexion.php'); // redirige l'utilisateur sur la page connexion.html après création de son compte
			
			/*$requser = $bdd->prepare("SELECT utilisateur FROM sessions WHERE ");
			$requser ->execute(array($user));
			$userexist = $requser->rowCount();
			
			
			
			if($userexist == 0)
			{
				//$userlength = strlen($user); // nbre de caractères saisie pour l'utilisateur
				$insertmbr = $bdd->prepare("INSERT INTO sessions (utilisateur, mdp) VALUES(?,?)");
				$insertmbr -> execute(array($user,$passwd));
				header('Location: connexion.html'); // redirige l'utilisateur sur la page connexion.html après création de son compte
			}
			else
			{
				$erreur = "Nom d'utilisateur déjà utilisé";
			}
			*/
			
		}
		else
		{
			$erreur= "Tous les champs doivent être remplies !";
		}
		
		$smarty -> assign("erreur", $erreur);
		$smarty ->display("inscription_V2.html");
		
	}
?>

