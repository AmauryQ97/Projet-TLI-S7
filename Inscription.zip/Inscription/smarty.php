<?php

	require("smarty-3.1.33/libs/Smarty.class.php");
	$smarty = new Smarty();
?>
	