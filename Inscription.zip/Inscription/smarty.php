<?php

	require(Smarty.class.php);
	$smarty = new Smarty();
?>
	